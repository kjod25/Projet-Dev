package Entities;

public enum Typec { spontannéé,non_spontannée

}
