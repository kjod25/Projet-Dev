import dash
import dash_bootstrap_components as dbc
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import plotly.express as px
import pandas as pd
import datetime


def init_dashboard(server):
    """Create a Plotly Dash dashboard."""
    dash_app = dash.Dash(__name__, server=server,
                         routes_pathname_prefix='/Image/',
                         external_stylesheets=[dbc.themes.BOOTSTRAP, "https://fonts.googleapis.com/css?family=Nunito+Sans&display=swap"]
                         )

    # Create Dash Layout

    SIDEBAR_STYLE = {
        "position": "fixed",
        "top": 0,
        "left": 0,
        "bottom": 0,
        "width": "16rem",
        "padding": "2rem 1rem",
        "background-color": "#FFC000",
        "font-family": "Nunito Sans"

    }

    CONTENT_STYLE = {
        "margin-left": "16rem",
        "padding": "2rem 1rem",
        "background-color": "#0A3754",
        "color": "white"
    }

    sidebar = html.Div(
        [
            html.Img(src=dash_app.get_asset_url('logo2.png'), style={'height':'10.5%', 'width':'14'}),
            html.Hr(),
            dbc.Nav(
                [
                    dbc.NavLink("Ajouter une image", href="/Image/", style={"color":"black", "font-size":"20px"}),
                    html.Br(),
                    dbc.NavLink("Carte", href="/Map/", style={"color":"black", "font-size":"20px"}),
                    html.Br(),
                    dbc.NavLink("Statistiques", href="/Stats/", style={"color":"black", "font-size":"20px"}),
                    html.Br(),
                    dbc.NavLink("Contact", href="/Contact/", style={"color":"black", "font-size":"20px"}),
                    html.Br(),
                ],
                vertical=True,
            ),
        ],
        style=SIDEBAR_STYLE,
    )

    content = html.Div(id="page-content", style=CONTENT_STYLE)

    mapbox_access_token = open("sources/plotlydash/token").read()

    us_cities = pd.read_csv("https://raw.githubusercontent.com/plotly/datasets/master/us-cities-top-1k.csv")

    fig = px.scatter_mapbox(us_cities, lat="lat", lon="lon", hover_name="City", hover_data=["State", "Population"],
                            color_discrete_sequence=["#FFC000"], zoom=4, height=800)
    fig.update_layout(mapbox_style="streets", mapbox_accesstoken=mapbox_access_token)
    fig.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})


    map_layout = html.Div([
        html.Div([
            html.H1("Trash location map", id="map_title", style={"text-align": "center", "font-family":"Nunito Sans"})]
        ),
        html.Hr(),

        html.Div([dcc.Graph(figure=fig)]),
        ], id="map-content"),

    ALLOWED_TYPES = (
        "text"
    )

    addImage_layout = html.Div([
        dcc.Upload(
            id='upload-image',
            children=html.Div([
                'Drag and Drop or ',
                html.A('Select Files')
            ]),
            style={
                'width': '100%',
                'height': '60px',
                'lineHeight': '60px',
                'borderWidth': '1px',
                'borderStyle': 'dashed',
                'borderRadius': '5px',
                'textAlign': 'center',
                'margin': '10px'
            },
            # Allow multiple files to be uploaded
            multiple=True
        ),
        html.Div(id='output-image-upload'),
        dcc.Dropdown(
            options=[
                {'label': 'Vendée', 'value': 'Vendée'},
                {'label': 'Pornic', 'value': 'Pornic'},
                {'label': 'La Baule-Escoublac', 'value': 'La Baule-Escoublac'},
                {'label': 'Bouin', 'value': 'Bouin'}
            ],
            placeholder="Where are you ?",
            style={"font-color":"black"}
        ),
        html.Div(
            [
                dcc.Input(
                    id="input_{}".format(_),
                    type=_,
                    placeholder="input type {}".format(_),
                )
                for _ in ALLOWED_TYPES
            ]
            + [html.Div(id="out-all-types")]
        )

    ])

    def parse_contents(contents, filename, date):
        return html.Div([
            html.H5(filename),
            html.H6(datetime.datetime.fromtimestamp(date)),

            # HTML images accept base64 encoded strings in the same format
            # that is supplied by the upload
            html.Img(src=contents, style={"height": "50%", "weight": "50%"}),
            html.Hr(),
            html.Div('Raw Content'),
            html.Pre(contents[0:200] + '...', style={
                'whiteSpace': 'pre-wrap',
                'wordBreak': 'break-all'
            })
        ])

    @dash_app.callback(
        Output("out-all-types", "children"),
        [Input("input_{}".format(_), "value") for _ in ALLOWED_TYPES],
    )
    def cb_render(*vals):
        return " | ".join((str(val) for val in vals if val))

    @dash_app.callback(Output('output-image-upload', 'children'),
                       Input('upload-image', 'contents'),
                       State('upload-image', 'filename'),
                       State('upload-image', 'last_modified'))
    def update_output(list_of_contents, list_of_names, list_of_dates):
        if list_of_contents is not None:
            children = [
                parse_contents(c, n, d) for c, n, d in
                zip(list_of_contents, list_of_names, list_of_dates)]
            return children


    df = {'Ville': ['Vendée', 'Pornic', 'La Baule-Escoublac', 'Bouin'], 'Plastic': [12, 65, 20, 79],'Bio': [10, 95, 10, 9], 'Verre': [45, 18, 55, 28]}

    fig2 = dcc.Graph(
            id='map-content',
            figure={
                'data': [
                    {'x': df['Ville'], 'y': df['Plastic'], 'type': 'bar', 'name':'Plastic'},
                    {'x': df['Ville'], 'y': df['Bio'], 'type': 'bar', 'name': 'Bio'},
                    {'x': df['Ville'], 'y': df['Verre'], 'type': 'bar','name': 'Verre'},

                ],
                'layout': {
                    'title': 'Trash Data Visualization'
                }
            },
        )

    stats_layout = html.Div([
        html.Div([
            html.H2("Statistiques", id="stats_title", style={"text-align": "center", "font-family":"Nunito Sans"} )
        ]),
        html.Hr(),
        html.Div(fig2)], id="example-graph"),
    # fig2.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

    dash_app.layout = html.Div([dcc.Location(id="url"), sidebar, content])

    @dash_app.callback(Output("page-content", "children"), [Input("url", "pathname")])
    def render_page_content(pathname):
        if pathname == "/Map/":
            return map_layout
        elif pathname == "/Stats/":
            return stats_layout
        elif pathname == "/Contact/":
            return html.P("Page contact")
        elif pathname == "/Image/":
            return addImage_layout
        # If the user tries to reach a different page, return a 404 message
        return dbc.Jumbotron(
            [
                html.H1("404: Not found", className="text-danger"),
                html.Hr(),
                html.P(f"The pathname {pathname} was not recognised..."),
            ]
        )

    return dash_app.server
